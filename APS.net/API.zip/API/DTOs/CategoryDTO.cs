﻿namespace API.DTOs
{
    public class CategoryDTO
    {
        public int id { get; set; } 
        public string name { get; set; }
    }
}
